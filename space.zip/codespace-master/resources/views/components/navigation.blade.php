<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="d-flex justify-content-between mb-3">
            <div id="back-space">
                <a href="{{ url()->previous() }}" class="btn btn-secondary"><i class="fas fa-angle-left"></i> Back</a>
            </div>
        </div>
    </div>
</div>
